HyperIstio is a standalone server including multiple istio components, with default
configuration suited for local testing.

- config defaults to tests/testdata/config
- default ports used
